setTimeout(function() {
    let jsParagraph = document.createElement("p");
    jsParagraph.textContent = "Hello from JavaScript.js!";
    document.body.appendChild(jsParagraph);
}, 1000);